<?php

class Contact extends Controller {

	function index(){
	
	
		$template = $this->loadView('handyman/contact');
		$title = 'Contact Us';
		$template->set('title', $title);
		$template->render();
	
	
	
	}




}
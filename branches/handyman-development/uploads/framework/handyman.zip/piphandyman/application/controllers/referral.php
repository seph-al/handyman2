<?php

class Referral extends Controller {



	function index(){
	
	
		$template = $this->loadView('handyman/referral');
		$title = 'Referrals';
		$template->set('title', $title);
		$template->render();
	
	}


}
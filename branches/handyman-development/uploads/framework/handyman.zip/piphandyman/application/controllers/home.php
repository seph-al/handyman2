<?php

class Home extends Controller {
	
	function index()
	{
		$template = $this->loadView('handyman/home');
		$title = 'Handyman.com';
		$template->set('title', $title);
		$template->render();
	}
	
	function terms(){
	
		$template = $this->loadView('handyman/terms');
		$title = 'Terms and Conditions';
		$template->set('title', $title);
		$template->render();
	
	}
	
	function about(){
	
		$template = $this->loadView('handyman/about');
		$title = 'About Us';
		$template->set('title', $title);
		$template->render();
	
	
	
	}
    
}

?>
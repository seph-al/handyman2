<?php

class Jobs extends Controller {

	function index(){
	
	
		$template = $this->loadView('handyman/jobs');
		$title = 'Handyman - Jobs';
		$template->set('title', $title);
		$template->render();
	
	
	
	}




}
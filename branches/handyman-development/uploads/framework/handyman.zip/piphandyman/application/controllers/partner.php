<?php

class Partner extends Controller {

	function index(){
	
	
		$template = $this->loadView('handyman/partner');
		$title = 'Partner with Us';
		$template->set('title', $title);
		$template->render();
	
	
	}




}
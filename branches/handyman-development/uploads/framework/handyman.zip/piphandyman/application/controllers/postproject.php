<?php

class Postproject extends Controller {



	function index(){
	
	
		$template = $this->loadView('handyman/postproject');
		$title = 'Post a project';
		$template->set('title', $title);
		$template->render();
	
	}


}
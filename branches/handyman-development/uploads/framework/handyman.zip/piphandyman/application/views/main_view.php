<?php include('header.php'); ?>
	
    <div id="content">
        
        <h1>Welcome to PIP</h1>
        <p>To get started please read the documentation at <a href="http://pip.dev7studios.com/">http://pip.dev7studios.com</a>.</p>
        
    </div>

<?php include('footer.php'); ?>
<?php  
    include('header.php');
?>
	<body>
		<?php include('navigation.php');?>
		<div class="section1">
			<div class="container text-center project">
				<div class="wrap-menu-content">
					<div id="estimate_display" class="row content-menu active">
						<div class="col-lg-6 col-lg-offset-3">
							<h1>
								Get an Estimate!
							</h1>
						</div>
						<div class="col-lg-8 col-lg-offset-2 form-project">
							<div class="row">
								<div class="col-lg-5">
									<div class="form-group">
										<select name="" id="" class="form-control input-lg">
											<option value="0">Project Type</option>
											<option value="1">Air Conditioning</option>
											<option value="2">Appliance Installation and Repair</option>
											<option value="3">Architect</option>
											<option value="4">Attics and Basements</option>
											<option value="54">Basements</option>
											<option value="5">Bathroom Remodeling</option>
											<option value="6">Cabinets</option>
											<option value="7">Carpentry</option>
											<option value="8">Cleaning</option>
											<option value="9">Closets and Storage</option>
											<option value="10">Countertops</option>
											<option value="11">Custom Home Building</option>
											<option value="55">Customer Home Remodeling</option>
											<option value="12">Decks</option>
											<option value="13">Demolition and Disposal</option>
											<option value="14">Designer</option>
											<option value="15">Drywall and Plastering</option>
											<option value="16">Electrical</option>
											<option value="17">Environmental/Disaster Services</option>
											<option value="18">Excavation</option>
											<option value="19">Fans and Ventilation</option>
											<option value="20">Fencing</option>
											<option value="21">Financing</option>
											<option value="22">Fireplace</option>
											<option value="23">Floor Coverings</option>
											<option value="24">Foundations/Retain Walls</option>
											<option value="25">Framing Systems</option>
											<option value="26">Garages/Outbuildings</option>
											<option value="27">Glass and Screens</option>
											<option value="28">Gutters/Sheet Metal</option>
											<option value="29">Handyman</option>
											<option value="30">Heating and Ventilation</option>
											<option value="56">Home Additions</option>
											<option value="31">Home Security</option>
											<option value="32">Hot Tubs</option>
											<option value="33">Inspection and Appraisal</option>
											<option value="34">Insulation and Weather Stripping</option>
											<option value="35">Kitchen Remodeling</option>
											<option value="36">Landscaping</option>
											<option value="37">Marine</option>
											<option value="38">Masonry and Stucco</option>
											<option value="39">Mold Remediation</option>
											<option value="40">Odd-Jobs</option>
											<option value="41">Other</option>
											<option value="59">Other</option>
											<option value="42">Painting/Wallcovering</option>
											<option value="43">Paving and Patios</option>
											<option value="44">Pest Control</option>
											<option value="45">Plumbing</option>
											<option value="46">Pools</option>
											<option value="57">Railings</option>
											<option value="47">Remodeling/Additions</option>
											<option value="48">Roofing</option>
											<option value="49">Siding/Residing</option>
											<option value="58">Smart House</option>
											<option value="50">Sunrooms</option>
											<option value="51">Tile and Stone</option>
											<option value="52">Waterproofing</option>
											<option value="53">Windows and Doors</option>
										</select>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="form-group">
										<label for="" class="sr-only">ZIP</label>
										<input placeholder="ZIP" type="text" class="form-control input-lg">
									</div>
								</div>
								<div class="col-lg-2">
									<div class="form-group">
										<a href="" class="btn btn-primary btn-lg btn-block">Go!</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="expert_display" class="row content-menu" style="display:none;">
						<div class="col-lg-6 col-lg-offset-3">
							<h1>Ask an Expert</h1>
						</div>
						<div class="col-lg-6 col-lg-offset-3 form-project form-blue">
							<div class="row">
								<div class="col-lg-5">
									<div class="form-group">
										<select name="" id="" class="form-control input-lg">
											<option value="0">Category</option>
											<option value="1">Air Conditioning</option>
											<option value="2">Appliance Installation and Repair</option>
											<option value="3">Architect</option>
											<option value="4">Attics and Basements</option>
											<option value="54">Basements</option>
											<option value="5">Bathroom Remodeling</option>
											<option value="6">Cabinets</option>
											<option value="7">Carpentry</option>
											<option value="8">Cleaning</option>
											<option value="9">Closets and Storage</option>
											<option value="10">Countertops</option>
											<option value="11">Custom Home Building</option>
											<option value="55">Customer Home Remodeling</option>
											<option value="12">Decks</option>
											<option value="13">Demolition and Disposal</option>
											<option value="14">Designer</option>
											<option value="15">Drywall and Plastering</option>
											<option value="16">Electrical</option>
											<option value="17">Environmental/Disaster Services</option>
											<option value="18">Excavation</option>
											<option value="19">Fans and Ventilation</option>
											<option value="20">Fencing</option>
											<option value="21">Financing</option>
											<option value="22">Fireplace</option>
											<option value="23">Floor Coverings</option>
											<option value="24">Foundations/Retain Walls</option>
											<option value="25">Framing Systems</option>
											<option value="26">Garages/Outbuildings</option>
											<option value="27">Glass and Screens</option>
											<option value="28">Gutters/Sheet Metal</option>
											<option value="29">Handyman</option>
											<option value="30">Heating and Ventilation</option>
											<option value="56">Home Additions</option>
											<option value="31">Home Security</option>
											<option value="32">Hot Tubs</option>
											<option value="33">Inspection and Appraisal</option>
											<option value="34">Insulation and Weather Stripping</option>
											<option value="35">Kitchen Remodeling</option>
											<option value="36">Landscaping</option>
											<option value="37">Marine</option>
											<option value="38">Masonry and Stucco</option>
											<option value="39">Mold Remediation</option>
											<option value="40">Odd-Jobs</option>
											<option value="41">Other</option>
											<option value="59">Other</option>
											<option value="42">Painting/Wallcovering</option>
											<option value="43">Paving and Patios</option>
											<option value="44">Pest Control</option>
											<option value="45">Plumbing</option>
											<option value="46">Pools</option>
											<option value="57">Railings</option>
											<option value="47">Remodeling/Additions</option>
											<option value="48">Roofing</option>
											<option value="49">Siding/Residing</option>
											<option value="58">Smart House</option>
											<option value="50">Sunrooms</option>
											<option value="51">Tile and Stone</option>
											<option value="52">Waterproofing</option>
											<option value="53">Windows and Doors</option>
										</select>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="form-group">
										<label for="" class="sr-only">Ask</label>
										<input placeholder="Ask" type="text" class="form-control input-lg">
									</div>
								</div>
								<div class="col-lg-2">
									<div class="form-group">
										<a href="" class="btn btn-danger btn-lg btn-block">Go!</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row nav-menu">
					<div class="col-lg-6 col-lg-offset-3">
						<div class="row wrap-menu-nav">
							<div id="esticlass" class="col-lg-6 sub-menu active">
								<a href="javascript:;" id="estimate"><i class="fa fa-fax "></i> Get an Estimate</a>
							</div>
							<div id="askclass" class="col-lg-6 sub-menu">
								<a href="javascript:;" id="expert"><i class="fa fa-info-circle "></i> Ask an Expert</a>
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="section2">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<h1>Get Matched to a Screened Professional Handyman</h1>
						<p>Handyman.com helps you find an experienced, professional Handyman contractor in your local area, FREE, NO OBLIGATIONS. Handyman.com is the industry leading portal for the home improvement, home repair and remodeling industry. Our free tools and services help both homeowners and contractors facilitate the process to accomplish your home repair and remodeling needs. Serving the Home and Contractor market. Why use our pros?</p>
						<p>For the commercial real estate market or projects over $5,000, Handyman.com offers a free consultation service to analyze your needs and find suppliers, general contractors and local professional service providers. Are you lacking a professional website or want to communicate more efficiently with your customer or contractor? Get a Free Webpage and Free Consultation and manage it online. Need professional and experienced contractors, subcontractors or handymen due to an increase in your work load? You have come to the right place at Handyman.com, your local referral and local handyman service provider.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="section3">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 f1">
						<a href="" class="feature-link text-center">
							post a project
							<span class="meta-desc">Home owner post your project free<i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f2">
						<a href="" class="feature-link text-center">
							FIND CONTRACTOR
							<span class="meta-desc">Contractors in Your Area Now  <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f3">
						<a href="" class="feature-link text-center">
							FIND PROJECT
							<span class="meta-desc">Get Contractor Projects  <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f4">
						<a href="" class="feature-link text-center">
							HOW IT WORKS
							<span class="meta-desc">Free Match-up for your project!   <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
				</div>
			</div>
		</div>
		
<script src="<?php echo BASE_URL; ?>js/home.js"></script>
<?php include ('footer.php')?>

$(document).ready(function(){

	$('#estimate').click(function(){
	
	
		$('#estimate_display').css('display','block');
		$('#expert_display').css('display','none');
		$('#esticlass').addClass('active');
		$('#askclass').removeClass('active');
	
	});
	
	$('#expert').click(function(){
	
		$('#estimate_display').css('display','none');
		$('#expert_display').css('display','block');
		$('#askclass').addClass('active');
		$('#esticlass').removeClass('active');
	
	
	});


});